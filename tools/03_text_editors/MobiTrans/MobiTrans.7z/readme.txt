MobiTrans by wl

platform:	multi / mobile / j2me / n-gage
game:		multi
developer:	wl
contacts:	wl_cool@mail.ru

repo:		https://github.com/1upus/N-Gage_stuff
date:		19:42 04.02.2018

Mobitrans - plugin based tool for translation some N-Gage and other mobile games

Included plugins for editing texts in:

Generic txt files
j2me Allods
j2me Battle Quest
j2me .class files
j2me Games by Digital Chocolate
j2me DoomRPG
j2me Mafia Wars 2
j2me Resident Evil Genesis
j2me Resident Evil: Confidential Report
j2me Some games by Rovio mobile
j2me Spyro (Vivendy Games)
j2me Some games by Sumea

n-gage Glimmerati
n-gage Call of Duty
n-gage The Elder Scrolls Travels: Shadowkey
n-gage Virtua Cop

