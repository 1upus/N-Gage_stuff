N-Gage game manager
-------------------
Save managing app (backup/restore/delete) for N-Gage games.

Ripped from N-Gage QD