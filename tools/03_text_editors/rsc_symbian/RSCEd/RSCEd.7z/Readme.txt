RSCed
Tool for editing strings in Symbian 6-8 Resource files .RSC