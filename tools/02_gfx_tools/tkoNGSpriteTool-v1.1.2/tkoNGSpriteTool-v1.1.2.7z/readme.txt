tkoNGSpriteTool v1.1.2

 TKO spritebank (global.spr) editor
 author:   metlob
 source:   metlob

 platform: Symbian
 game:     N-Gage Call of Duty / N-Gage TEST: Shadowkey
 dev:      
 publ:     
 files:    *.spr
 repo:     https://github.com/1upus/N-Gage_stuff

Tool for export/import gfx from/to TKO spritebanks (global.spr)