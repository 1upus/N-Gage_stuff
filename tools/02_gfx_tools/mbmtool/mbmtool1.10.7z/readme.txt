 mbmtool by Alezz

 symbian multibitmap (.mbm) editor
 author:   Alezz
 source:   Oslik.ru

 platform: Symbian
 game:     
 dev:      
 publ:     
 files:    *.mbm
 repo:     https://github.com/1upus/N-Gage_stuff

Tool for editing gfx in symbian .mbm files