#include <cstdio>
#include <inttypes.h>
#include <mem.h>
#include <io.h>
#include <algorithm>
#include "zlib/zlib.h"

#pragma pack(push, 1)

struct FileRecord
{
    uint32_t unk_pre;
    uint32_t offset;
    uint32_t size;
    uint32_t unk_post;
};

struct Header
{
    char       signature[4]; // "PMAN"
    uint32_t   file_count;
    char       copyright[56];
    //FileRecord files[0];
};

struct ZLHeader
{
    char     signature[2];
    unsigned file_size : 24;
    //uint8_t  zlib_stream[0];
};

#pragma pack(pop)

#define CHUNK (1024 * 256)

unsigned char buf_in[CHUNK];
unsigned char buf_out[CHUNK];

int ZCompress(FILE *stream_in, int size_in, FILE *stream_out, int size_out)
{
    bool first = true;
    //if(size_out == -1) size_out =
    z_stream_s strm;
    memset(&strm, 0, sizeof(z_stream));
    //deflateInit_(&strm, Z_BEST_COMPRESSION, zlib_version, sizeof(z_stream_s));
    //deflateInit(&strm, Z_BEST_COMPRESSION);
    int ret = deflateInit(&strm, Z_BEST_COMPRESSION);
    if(ret != Z_OK)
    {
        goto l_error;
    }

    do
    {
        size_t chunk = std::min(CHUNK, size_in);
        strm.avail_in = fread(buf_in, chunk, 1, stream_in);
        strm.next_in = buf_in;
        if(chunk != strm.avail_in)
        {
            ret = -1;
            goto l_error;
        }
        size_in -= chunk;
        do
        {
            strm.avail_out = CHUNK;
            strm.next_out = buf_out;
            ret = deflate(&strm, size_in == 0 ? Z_FINISH : Z_NO_FLUSH);
            if(ret == Z_STREAM_ERROR)
            {
                goto l_error;
            }
            size_t have = CHUNK - strm.avail_out;
            if(first)
            {
                buf_out[0] = 0x78;
                buf_out[1] = 0xDA;
                first = false;
            }
            if(fwrite(buf_out, have, 1, stream_out) != have)
            {
                ret = -1;
                goto l_error;
            }
        }
        while (strm.avail_out == 0);
        if (strm.avail_in != 0)
        {
            ret = -1;
            goto l_error;
        }
    }
    while (size_in > 0);
    if(ret != Z_STREAM_END)
        goto l_error;
    ret = Z_OK;
l_error:
    deflateEnd(&strm);
    return ret;

    //strm.zalloc = &zliballocmem;
}


int ZDecompress(FILE *stream_in, int size_in, FILE *stream_out, int size_out)
{
    int ret;
    unsigned int have;
    z_stream strm;
    bool first = true;

    memset(&strm, 0, sizeof(z_stream));
    ret = inflateInit(&strm);
    if (ret != Z_OK)
    {
        return ret;
    }

    /* decompress until deflate stream ends or end of file */
    do
    {
        size_t chunk = std::min(CHUNK, size_in);
        strm.avail_in = fread(buf_in, 1, chunk, stream_in);
        if(chunk != strm.avail_in)
        {
            inflateEnd(&strm);
            return -100;
        }
        if (chunk == 0)
        {
            break;
        }
        size_in -= chunk;
        strm.next_in = buf_in;
        if(first)
        {
            buf_in[0] = 0x78;
            buf_in[1] = 0x9C;
            first = false;
        }
        do
        {
            strm.avail_out = CHUNK;
            strm.next_out = buf_out;
            ret = inflate(&strm, Z_NO_FLUSH);
            //assert(ret != Z_STREAM_ERROR);  /* state not clobbered */
            if(ret == Z_STREAM_ERROR)
            {
                inflateEnd(&strm);
                return Z_STREAM_ERROR;
            }
            switch (ret)
            {
            case Z_NEED_DICT:
                ret = Z_DATA_ERROR;     /* and fall through */
            case Z_DATA_ERROR:
            case Z_MEM_ERROR:
                inflateEnd(&strm);
                return ret;
            }
            have = CHUNK - strm.avail_out;
            if(fwrite(buf_out, 1, have, stream_out) != have)
            {
                inflateEnd(&strm);
                return Z_ERRNO;
            }
        }
        while (strm.avail_out == 0);
    }
    while (size_in > 0);

    inflateEnd(&strm);
    return ret == Z_STREAM_END ? Z_OK : Z_DATA_ERROR;
}

int StoreFile(FILE *stream_in, FILE *stream_out, size_t size)
{
    while(size > 0)
    {
        size_t chunk = std::min((size_t)CHUNK, size);
        fread(buf_in, chunk, 1, stream_in);
        fwrite(buf_in, chunk, 1, stream_out);
        size -= chunk;
    }
    return 0;
}

int extract_files(const char *pak_file, const char *out_dir)
{
    Header header;
    if(access(out_dir, 0) != 0) return -1;
    FILE* pak = fopen(pak_file, "rb");
    if(!pak) return -1;

    char path[MAX_PATH];

    fread(&header, sizeof(header), 1, pak);
    FileRecord *files = new FileRecord[header.file_count];
    fread(files, header.file_count * sizeof(FileRecord), 1, pak);

    for(uint32_t i = 0; i < header.file_count; i++)
    {
        printf("Extracting file %d...\n", i);

        sprintf(path, "%s\\%4.4d.bin", out_dir, i);

        fseek(pak, files[i].offset, SEEK_SET);

        FILE* f = fopen(path, "wb");
        ZLHeader zl_header;
        if(files[i].size <= sizeof(zl_header) + 2)
        {
            StoreFile(pak, f, files[i].size);
        }
        else
        {
            fread(&zl_header, sizeof(zl_header), 1, pak);
            if(strncmp(zl_header.signature, "ZL", 2) == 0)
            {
                ZDecompress(pak, files[i].size - sizeof(zl_header), f, zl_header.file_size);
            }
            else
            {
                fwrite(&zl_header, sizeof(zl_header), 1, f);
                StoreFile(pak, f, files[i].size - sizeof(zl_header));
            }
        }
        fclose(f);
    }

    delete []files;
    fclose(pak);
    return 0;
}

int main(int argc, const char *argv[])
{
    //extract_files("C:\\Documents and Settings\\admin\\������� ����\\NGE\\NGE\\Ashen_RETAIL_NGAGE-ENGAGE\\System\\Apps\\6R21\\PackFile.Dat",
    //              "C:\\Documents and Settings\\admin\\������� ����\\NGE\\NGE\\Ashen_RETAIL_NGAGE-ENGAGE\\System\\Apps\\6R21\\files"
     //             );

    if(argc < 3) return 0;
    extract_files(argv[1], argv[2]);
    return 0;
}
